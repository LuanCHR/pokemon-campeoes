# Meus campeões Pokémon

Site pessoal com o ranking dos Pokémon que mais zeraram a liga e os times campeões de cada jogo.

## Como adicionar um jogo
Abra `dados.json` e adicione um item em `jogos`:

```json
{ "nome": "Pokémon Black", "trofeu": "liga", "time": [635, 550, 553, 571, 612, 26],
  "extras": [ { "pokemon": 635, "trofeu": "craft" } ] }
```

- `time`: números da Pokédex dos 6 Pokémon. O sprite e o nome vêm da internet sozinhos.
- `trofeu`: o troféu que o time inteiro ganhou (um dos `id` da lista `trofeus`).
- `extras`: troféus que só um Pokémon ganhou (opcional).

O ranking e as contagens embaixo de cada Pokémon são calculados sozinhos.

## Como criar um troféu novo
1. Coloque a imagem (PNG, uns 64x64, fundo transparente) em `img/trofeus/`.
2. Adicione uma linha em `trofeus` no `dados.json` com `id`, `nome` (o texto que aparece ao passar o cursor) e `imagem`.

Se a imagem ainda não existe, o site mostra um quadradinho tracejado no lugar.

## Ver no seu computador
Abra a pasta no VS Code e use a extensão Live Server (clique direito no `index.html` > Open with Live Server). Abrir o arquivo com duplo clique não carrega o `dados.json`.

## Publicar no GitHub Pages
1. Crie um repositório e envie todos os arquivos.
2. Em Settings > Pages, escolha a branch `main` e a pasta `/ (root)`.
3. O site fica em `https://SEU-USUARIO.github.io/NOME-DO-REPO/`.
