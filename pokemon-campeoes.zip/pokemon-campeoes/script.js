const SPRITE = id => `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`;
const $ = s => document.querySelector(s);

function el(tag, cls, txt) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (txt != null) e.textContent = txt;
  return e;
}

const cacheNomes = JSON.parse(localStorage.getItem('nomes') || '{}');
async function nomeDe(id) {
  if (cacheNomes[id]) return cacheNomes[id];
  try {
    const r = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}`);
    const n = (await r.json()).name;
    cacheNomes[id] = n.charAt(0).toUpperCase() + n.slice(1);
    localStorage.setItem('nomes', JSON.stringify(cacheNomes));
    return cacheNomes[id];
  } catch { return `#${id}`; }
}

function contar(dados) {
  const c = {};
  const get = id => (c[id] ??= { ligas: 0, t: {} });
  dados.jogos.forEach(j => {
    j.time.forEach(id => {
      const p = get(id);
      p.ligas++;
      p.t[j.trofeu] = (p.t[j.trofeu] || 0) + 1;
    });
    (j.extras || []).forEach(e => {
      const p = get(e.pokemon);
      p.t[e.trofeu] = (p.t[e.trofeu] || 0) + 1;
    });
  });
  return c;
}

function trofeu(t, n) {
  const b = el('span', 'badge');
  const ic = el('span', 'tro');
  ic.tabIndex = 0;
  ic.dataset.nome = t.nome;
  const img = new Image();
  img.alt = t.nome;
  img.onerror = () => img.remove();
  img.src = t.imagem;
  ic.append(img);
  b.append(ic);
  if (n != null) b.append(String(n));
  return b;
}

function sprite(id, nome) {
  const i = new Image();
  i.className = 'spr';
  i.alt = nome;
  i.loading = 'lazy';
  i.src = SPRITE(id);
  return i;
}

function badges(dados, c, id, cls) {
  const bs = el('div', 'badges' + (cls ? ' ' + cls : ''));
  dados.trofeus.forEach(t => {
    const n = c[id].t[t.id];
    if (n) bs.append(trofeu(t, n));
  });
  return bs;
}

async function render(dados) {
  const c = contar(dados);
  const ids = Object.keys(c).map(Number);
  const nomes = Object.fromEntries(await Promise.all(ids.map(async id => [id, await nomeDe(id)])));
  const total = id => Object.values(c[id].t).reduce((a, b) => a + b, 0);
  ids.sort((a, b) => c[b].ligas - c[a].ligas || total(b) - total(a));

  ids.forEach((id, i) => {
    const li = el('li', 'linha');
    const info = el('div', 'info');
    const l = c[id].ligas;
    info.append(el('strong', null, nomes[id]), el('span', null, `${l} ${l === 1 ? 'liga vencida' : 'ligas vencidas'}`));
    li.append(el('span', 'pos', i + 1), sprite(id, nomes[id]), info, badges(dados, c, id));
    $('#ranking').append(li);
  });

  dados.jogos.forEach(j => {
    const card = el('article', 'jogo');
    const hd = el('header');
    const t = dados.trofeus.find(x => x.id === j.trofeu);
    if (t) hd.append(trofeu(t));
    hd.append(el('h3', null, j.nome));
    const time = el('div', 'time');
    j.time.forEach(id => {
      const m = el('div', 'membro');
      m.append(sprite(id, nomes[id]), el('span', 'nome', nomes[id]), badges(dados, c, id, 'mini'));
      time.append(m);
    });
    card.append(hd, time);
    $('#times').append(card);
  });
}

fetch('dados.json')
  .then(r => r.json())
  .then(render)
  .catch(() => { $('#erro').hidden = false; });
